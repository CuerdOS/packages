#ifndef __I3IPC_GLIB_H__
#define __I3IPC_GLIB_H__

#include <i3ipc-glib/i3ipc-con.h>
#include <i3ipc-glib/i3ipc-connection.h>
#include <i3ipc-glib/i3ipc-enum-types.h>
#include <i3ipc-glib/i3ipc-event-types.h>
#include <i3ipc-glib/i3ipc-reply-types.h>

#endif /* __I3IPC_GLIB_H__ */
