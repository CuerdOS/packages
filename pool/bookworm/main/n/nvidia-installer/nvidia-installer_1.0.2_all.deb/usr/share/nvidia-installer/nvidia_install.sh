#!/bin/bash

# Mostrar información de la instalación en la ventana de progreso
echo "10" ; sleep 1
echo "# Actualizando el sistema..."
sudo cp /usr/share/nvidia-installer/nvidia-drivers /etc/apt/sources.list.d/
sudo cp /usr/share/keyrings/nvidia-drivers.gpg /usr/share/keyrings/
sudo apt-fast update -y

echo "30" ; sleep 1
echo "# Instalando el controlador NVIDIA..."
sudo apt-fast install -y nvidia-driver

echo "100" ; sleep 1
echo "# Instalación completada con éxito."

